#!/usr/bin/env python

from distutils.core import setup

setup(name='Yapps',
      version='2.1.1',
      description='Yet Another Python Parser System',
      author='Amit Patel',
      author_email='amitp@theory.stanford.edu',
      url='http://theory.stanford.edu/~amitp/Yapps/',
      license='http://www.opensource.org/licenses/mit-license.php',
      package_dir={'':'lib'},
      packages=['yapps'],
      scripts = ['scripts/yapps2']
      )

